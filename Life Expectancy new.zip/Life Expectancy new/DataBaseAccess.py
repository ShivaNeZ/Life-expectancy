from Bl import *
import pyodbc


def create_connection():
    server = 'host'
    database = 'LifeExpectancy'
    
    
    
    
    connection_string = f'DRIVER=ODBC Driver 17 for SQL Server;SERVER={server};DATABASE={database}'

    connection = pyodbc.connect(connection_string)

    return connection



def insert_location(connection, data):
    try:
        cursor = connection.cursor()
        query = "INSERT INTO Location (LocationID, Location) VALUES (?, ?);"
        cursor.executemany(query, data.values.tolist())
        connection.commit()
    except Exception as e:
        print(f"Error inserting data into Location: {e}")
        connection.rollback()

def insert_time_period(connection, data):
    try:
        cursor = connection.cursor()
        query = "INSERT INTO TimePeriod (PeriodID, Period) VALUES (?, ?);"
        cursor.executemany(query, data.values.tolist())
        connection.commit()
    except Exception as e:
        print(f"Error inserting data into TimePeriod: {e}")
        connection.rollback()

def insert_indicator(connection, data):
    try:
        cursor = connection.cursor()
        query = "INSERT INTO Indicator (IndicatorID, Indicator) VALUES (?, ?);"
        cursor.executemany(query, data.values.tolist())
        connection.commit()
    except Exception as e:
        print(f"Error inserting data into Indicator: {e}")
        connection.rollback()

def insert_demographic_category(connection, data):
    try:
        cursor = connection.cursor()
        query = "INSERT INTO DemographicCategory (Dim1ID, Dim1) VALUES (?, ?);"
        cursor.executemany(query, data.values.tolist())
        connection.commit()
    except Exception as e:
        print(f"Error inserting data into DemographicCategory: {e}")
        connection.rollback()

def insert_hale_life_data(connection, data):
    try:
        cursor = connection.cursor()
        query = "INSERT INTO HaleLifeData (HaleLifeID, LocationID, PeriodID, IndicatorID, Dim1ID, HaleExpectancy, LifeExpectancy, PercentHaleInLifeExpectancy) VALUES (?, ?, ?, ?, ?, ?, ?, ?);"
        cursor.executemany(query, data.values.tolist())
        connection.commit()
    except Exception as e:
        print(f"Error inserting data into HaleLifeData: {e}")
        connection.rollback()

def close_connection(connection):
    connection.close()
