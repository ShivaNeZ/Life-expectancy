import pandas as pd

from DataBaseAccess import *
def read_csv(file1,file2,file3,file4):
    
    try:
        data1 = pd.read_csv(file1)
        data2= pd.read_csv(file2)
        data3 = pd.read_csv(file3)
        data4 = pd.read_csv(file4)
        
        
        
    except Exception as e:
        print("Error reading CSV file ")
    data = [data1,data2]  
    return data

def merge(data):
    merged_data = {}
    for dataf in data:
        for key in dataf.columns:
            if key not in merged_data:
                merged_data[key]=[]
            merged_data[key].extend(dataf[key])
            
    return(merged_data)