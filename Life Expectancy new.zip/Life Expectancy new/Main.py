from Bl import *
def main():
   data = read_csv('HALElifeExpectancyAtBirth.csv','HALeWHOregionLifeExpectancyAtBirth.csv','lifeExpectancyAtBirth.csv','WHOregionLifeExpectancyAtBirth.csv')

   merged_data = merge(data)
   connection = create_connection()

   insert_location(connection, merged_data['Location'].values.tolist())
   insert_time_period(connection, merged_data['Period'].values.tolist())
   insert_indicator(connection, merged_data['Indicator'].values.tolist())
   insert_demographic_category(connection, merged_data['Dim1'].values.tolist())
   insert_hale_life_data(connection, merged_data[['HaleExpectancy', 'LifeExpectancy', 'PercentHaleInLifeExpectancy']].values.tolist())

   close_connection(connection)



if __name__ == '__main__':
    main()